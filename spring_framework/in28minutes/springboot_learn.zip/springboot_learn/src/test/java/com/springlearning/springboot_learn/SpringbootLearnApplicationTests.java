package com.springlearning.springboot_learn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootLearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
